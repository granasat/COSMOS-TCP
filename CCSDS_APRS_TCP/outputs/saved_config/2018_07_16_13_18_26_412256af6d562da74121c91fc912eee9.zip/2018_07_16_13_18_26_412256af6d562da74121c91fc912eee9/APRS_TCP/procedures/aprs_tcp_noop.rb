require 'cosmos'
require 'aprs_tcp.rb'

aprs_tcp = AprsTcp.new
aprs_tcp.noop
