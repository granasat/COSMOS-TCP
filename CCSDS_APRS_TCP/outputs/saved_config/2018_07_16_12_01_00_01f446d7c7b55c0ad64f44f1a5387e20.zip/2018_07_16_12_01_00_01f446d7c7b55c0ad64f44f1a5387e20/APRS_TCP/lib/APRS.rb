require 'cosmos'
require 'cosmos/interfaces/tcpip_client_interface'
i = Cosmos::TcpipClientInterface.new('localhost',2055,2055,nil,nil,'LENGTH',32,16,7)
i.connect
loop do
  pkt = Cosmos::System.telemetry.identify!(i.read.buffer, ['APRS_TCP_INT'])
  puts pkt
end
